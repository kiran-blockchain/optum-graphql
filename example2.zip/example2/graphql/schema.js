const{gql} = require('apollo-server-express')
const typeDefs = gql`
  type Post {
    id: ID!
    title: String!
    content: String!
    comments(limit: Int, offset: Int): [Comment]
  }

  type Comment {
    id: ID!
    content: String!
    postId: ID!
  }

  type Query {
    posts(limit: Int, offset: Int): [Post]
    post(id: ID!): Post
    comments(postId: ID!, limit: Int, offset: Int): [Comment]
  }
`;

module.exports={
  typeDefs
}