import {useQuery,gql} from '@apollo/client';

const GET_POSTS_OLD = gql`
query {
  posts(limit: 2, offset: 0) {
    id
    title
    content
    
    comments(limit: 2) {
      id
      content
    }
  }
}`
const GET_POSTS=gql`
query($postId: ID!, $limit: Int) {
  posts(limit: $limit, offset: 0) {
    id
    title
    content
  }
  comments(postId: $postId, limit: $limit) {
    content
    id
    postId
  }
}
`

const Posts =()=>{
    const {loading,error,data} = useQuery(GET_POSTS,{
        variables:{ postId:1,limit:1}
    });
    if(loading) return <p>Loading!!!!!</p>
    if(error) return <p>Error in Fetching the data</p>
    return data.posts.map(({id,title,content})=>(
        <div key={id}>
            <h4>{title}</h4>
            <h5>{content}</h5>
        </div>
    ));
 }
 export default Posts;