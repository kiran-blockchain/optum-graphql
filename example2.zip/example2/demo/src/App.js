import logo from './logo.svg';
import './App.css';
import { ApolloClient,HttpLink,ApolloProvider, InMemoryCache } from '@apollo/client';
import Posts from './Posts';

const httpLink = new HttpLink({
  uri:"http://localhost:4000/graphql"
});

const client  = new ApolloClient({
  link: httpLink,
  cache:new InMemoryCache()
})
function App() {
  return (
    <ApolloProvider client={client}>
    <div className="App">
     <h1>Welcome to graphql</h1>
     <Posts/>
    </div>
    </ApolloProvider>
  );
}

export default App;
