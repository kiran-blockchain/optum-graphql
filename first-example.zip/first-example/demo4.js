const express = require('express');
const { ApolloServer, gql } = require('apollo-server-express');

// Define GraphQL schema
const typeDefs = gql`
  type Post {
    id: ID!
    title: String!
    content: String!
    comments(limit: Int, offset: Int): [Comment]
  }

  type Comment {
    id: ID!
    content: String!
    postId: ID!
  }

  type Query {
    posts(limit: Int, offset: Int): [Post]
    post(id: ID!): Post
    comments(postId: ID!, limit: Int, offset: Int): [Comment]
  }
`;

// Mock data
const posts = [
  { id: '1', title: 'Post 1', content: 'Content of post 1' },
  { id: '2', title: 'Post 2', content: 'Content of post 2' },
];

const comments = [
  { id: '1', content: 'Comment 1', postId: '1' },
  { id: '2', content: 'Comment 2', postId: '1' },
  { id: '3', content: 'Comment 3', postId: '2' },
];

// Define resolvers
const resolvers = {
  Query: {
    posts: (_, { limit = 10, offset = 0 }) => {
      return posts.slice(offset, offset + limit);
    },
    post: (_, { id }) => {
      return posts.find(post => post.id === id);
    },
    comments: (_, { postId, limit = 10, offset = 0 }) => {
      const filteredComments = comments.filter(comment => comment.postId === postId);
      return filteredComments.slice(offset, offset + limit);
    }
  },
  Post: {
    comments: (post, { limit = 10, offset = 0 }) => {
      const filteredComments = comments.filter(comment => comment.postId === post.id);
      return filteredComments.slice(offset, offset + limit);
    }
  }
};

// Setup Apollo Server
const server = new ApolloServer({ typeDefs, resolvers });
const app = express();
server.start().then(() => {
  server.applyMiddleware({ app });

  // Start the server
  app.listen({ port: 4000 }, () =>
    console.log(`🚀 Server ready at http://localhost:4000${server.graphqlPath}`)
  );
});
