const {posts,users,comments} = require("../data/posts")
// Define your resolvers here
const resolvers = {
    Query: {
      posts: () => {
        // Return all posts; ensure this fetches data as expected
        return posts; 
      },
      post: (parent, { id }) => {
        // Fetch a single post by id
        return posts.find(post => post.id === id);
      },
      comments: () => {
        // Return all comments
        return comments;
      },
      comment: (parent, { id }) => {
        // Fetch a single comment by id
        return comments.find(comment => comment.id === id);
      }
    },
    Post: {
      comments: (post) => {
        // Fetch comments related to a post
        return comments.filter(comment => comment.postId === post.id);
      }
    },
    Comment: {
      post: (comment) => {
        // Fetch the post related to a comment
        return posts.find(post => post.id === comment.postId);
      }
    }
  };
  
  
module.exports={
    resolvers
}