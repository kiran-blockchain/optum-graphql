const { buildSchema } = require('graphql');
//the "!" denotes a mandatory field in the schema
const schema = buildSchema(`
   type User {
    id: ID!
    name: String!
    email: String!
    posts: [Post]
    comments: [Comment]
  }

  type Post {
    id: ID!
    title: String!
    content: String!
    user: User!
    comments: [Comment]
  }

  type Comment {
    id: ID!
    content: String!
    user: User!
    post: Post!
  }

  type Query {
    posts: [Post]
    post(id: ID!): Post
    comments: [Comment]
    comment(id: ID!): Comment
  }`);
module.exports = { schema }