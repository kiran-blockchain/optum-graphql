module.exports.authors = [{
    id: "1", name: 'Kiran Paturi'
},
{
    id: "2", name: 'Jon Doe'
}];

module.exports.books = [{
    id: "1", title: 'Ramayan',authorId :"1"},
    {id: "2", title: 'Harry Potter',authorId :"2"},
    {id: "3", title: 'Lord of the Rings',authorId :"1"},
    {id: "4", title: 'Nagas',authorId :"2"},
];