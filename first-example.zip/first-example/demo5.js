const express = require('express');
const { ApolloServer, gql } = require('apollo-server-express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Define GraphQL schema
const typeDefs = gql`
  type User {
    id: ID!
    username: String!
    email: String!
    posts: [Post]
  }

  type Post {
    id: ID!
    title: String!
    content: String!
    author: User!
    comments: [Comment]
    tags: [Tag]
  }

  type Comment {
    id: ID!
    content: String!
    author: User!
    post: Post!
  }

  type Tag {
    id: ID!
    name: String!
    posts: [Post]
  }

  type Query {
    posts(tag: String, limit: Int, offset: Int): [Post]
    post(id: ID!): Post
    comments(postId: ID!): [Comment]
    users: [User]
  }

  type Mutation {
    createPost(title: String!, content: String!, tags: [String]!): Post
    updatePost(id: ID!, title: String, content: String): Post
    deletePost(id: ID!): Post
    login(username: String!, password: String!): String # JWT token
  }

  type Subscription {
    postAdded: Post
  }
`;

const SECRET_KEY = 'your-secret-key';
let users = [
  { id: '1', username: 'Alice', email: 'alice@example.com', password: bcrypt.hashSync('password123') }
];
let posts = [
  { id: '1', title: 'GraphQL Basics', content: 'Introduction to GraphQL...', authorId: '1', tags: ['GraphQL'] }
];
let comments = [
  { id: '1', content: 'Great post!', authorId: '1', postId: '1' }
];
let tags = [{ id: '1', name: 'GraphQL', postIds: ['1'] }];

// Define resolvers
const resolvers = {
  Query: {
    posts: (_, { tag, limit = 10, offset = 0 }) => {
      let filteredPosts = posts;
      if (tag) {
        filteredPosts = filteredPosts.filter(post => post.tags.includes(tag));
      }
      return filteredPosts.slice(offset, offset + limit);
    },
    post: (_, { id }) => posts.find(post => post.id === id),
    comments: (_, { postId }) => comments.filter(comment => comment.postId === postId),
    users: () => users,
  },
  Mutation: {
    createPost: (_, { title, content, tags }, { user }) => {
      if (!user) throw new Error('Authentication required');
      const newPost = { id: String(posts.length + 1), title, content, authorId: user.id, tags };
      posts.push(newPost);
      return newPost;
    },
    updatePost: (_, { id, title, content }, { user }) => {
      if (!user) throw new Error('Authentication required');
      const post = posts.find(p => p.id === id && p.authorId === user.id);
      if (!post) throw new Error('Post not found or permission denied');
      if (title) post.title = title;
      if (content) post.content = content;
      return post;
    },
    deletePost: (_, { id }, { user }) => {
      if (!user) throw new Error('Authentication required');
      const postIndex = posts.findIndex(p => p.id === id && p.authorId === user.id);
      if (postIndex === -1) throw new Error('Post not found or permission denied');
      const [removed] = posts.splice(postIndex, 1);
      return removed;
    },
    login: (_, { username, password }) => {
      const user = users.find(user => user.username === username && bcrypt.compareSync(password, user.password));
      if (!user) throw new Error('Invalid credentials');
      return jwt.sign({ id: user.id, username: user.username }, SECRET_KEY, { expiresIn: '1d' });
    }
  },
  User: {
    posts: (user) => posts.filter(post => post.authorId === user.id),
  },
  Post: {
    author: (post) => users.find(user => user.id === post.authorId),
    comments: (post) => comments.filter(comment => comment.postId === post.id),
    tags: (post) => tags.filter(tag => post.tags.includes(tag.name)),
  },
  Comment: {
    author: (comment) => users.find(user => user.id === comment.authorId),
    post: (comment) => posts.find(post => post.id === comment.postId),
  },
  Tag: {
    posts: (tag) => posts.filter(post => post.tags.includes(tag.name)),
  }
};

// Setup Apollo Server
const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: ({ req }) => {
    const token = req.headers.authorization || '';
    try {
      const user = jwt.verify(token, SECRET_KEY);
      return { user };
    } catch {
      return {};
    }
  }
});
const app = express();
server.start().then(() => {
  server.applyMiddleware({ app });

  // Start the server
  app.listen({ port: 4000 }, () =>
    console.log(`🚀 Server ready at http://localhost:4000${server.graphqlPath}`)
  );
});
